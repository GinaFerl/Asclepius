package com.dicoding.asclepius.api

data class NewsItem(
    val title: String,
    val urlToImage: String,
    val url: String
)